const mongoose = require('mongoose');
const User = require('../models/User');
const Class = require('../models/Class');
const Subject = require('../models/Subject');
const Student = require('../models/Student');
const Grade = require('../models/Grade');
const EditRequest = require('../models/GradeEditRequest');
const Audit = require('../models/AcademicAudit');
const P = require('./academic-policy');
const GradingAccess = require('./grading-access');
const SubjectLeadership = require('../models/SubjectLeadership');
const SF9 = require('./sf9');
const TermGrades = require('./term-grades');
const Attendance = require('../models/Attendance');
const NarrativeReport = require('../models/NarrativeReport');
const CoreValueReport = require('../models/CoreValueReport');
const CoreValues = require('./core-values');
const dailyAttendance = require('./daily-attendance');
async function advisorySubject(actor, subjectId) {
  await teacher(actor);
  const subject = await Subject.findById(P.id(subjectId, 'subject')).session(null);
  if (!subject) P.fail('Subject not found.', 404);
  const cls = await Class.findById(subject.class).session(null);
  if (!cls || String(cls.adviser) !== actor.userId) P.fail("Only the student's class adviser can manage values and narrative reports.", 403);
  return subject;
}

async function coreValueReports(actor, subjectId) {
  const subject = await advisorySubject(actor, subjectId);
  const students = await Student.find({ $and: [P.rosterFilter(subject), { class: subject.class }] }).sort({ lastName: 1, firstName: 1 });
  const reports = await CoreValueReport.find({ subject: subject._id });
  return { roster: students.map((student) => ({
    studentId: student._id, firstName: student.firstName, lastName: student.lastName,
    reports: reports.filter((report) => String(report.student) === String(student._id)).map((report) => ({
      term: report.term, category: report.category,
      ratings: report.ratings instanceof Map ? Object.fromEntries(report.ratings) : report.ratings || {}
    }))
  })) };
}
async function saveCoreValues(actor, subjectId, studentId, body) {
  const term = narrativeTerm(body?.term);
  const category = body?.category;
  if (!['filipino', 'personal'].includes(category)) P.fail('Select a valid core values category.');
  if (!body.ratings || typeof body.ratings !== 'object' || Array.isArray(body.ratings)) P.fail('Enter valid ratings.');
  const allowed = new Set(CoreValues[category].items.map((item) => item[0]));
  const ratings = {};
  for (const [key, value] of Object.entries(body.ratings)) {
    if (!allowed.has(key) || typeof value !== 'string' || !['', 'AO', 'SO', 'RO', 'NO'].includes(value))
      P.fail('Select AO, SO, RO, or NO for each behavior statement.');
    ratings[key] = value;
  }
  const subject = await advisorySubject(actor, subjectId);
  const student = await Student.findById(P.id(studentId, 'student'));
  if (!student || !P.enrolled(student, subject) || String(student.class) !== String(subject.class)) P.fail('This student is not enrolled in your subject.', 403);
  const filter = { subject: subject._id, student: student._id, term, category };
  const update = { $set: { ratings, updatedBy: actor.userId } };
  try {
    await CoreValueReport.updateOne(filter, update, { upsert: true, runValidators: true });
  } catch (error) {
    if (error.code !== 11000) throw error;
    await CoreValueReport.updateOne(filter, update, { runValidators: true });
  }
  return { studentId, term, category, ratings };
}
function narrativeTerm(term) {
  if (![1, 2, 3].includes(term)) P.fail('Select a term from 1 to 3.');
  return term;
}
async function narrativeReports(actor, subjectId, term) {
  narrativeTerm(term);
  const subject = await advisorySubject(actor, subjectId);
  const students = await Student.find({ $and: [P.rosterFilter(subject), { class: subject.class }] }).sort({ lastName: 1, firstName: 1 });
  const reports = await NarrativeReport.find({ subject: subject._id, term });
  const byStudent = new Map(reports.map((report) => [String(report.student), report]));
  return { roster: students.map((student) => ({
    studentId: student._id, firstName: student.firstName, lastName: student.lastName,
    canDo: byStudent.get(String(student._id))?.canDo || '',
    improving: byStudent.get(String(student._id))?.improving || ''
  })) };
}
async function saveNarrativeReport(actor, subjectId, studentId, body) {
  const term = narrativeTerm(body?.term);
  const text = {};
  for (const field of ['canDo', 'improving']) {
    if (typeof body[field] !== 'string' || body[field].length > 10000)
      P.fail('Each narrative must be text of at most 10,000 characters.');
    text[field] = body[field];
  }
  const subject = await advisorySubject(actor, subjectId);
  const student = await Student.findById(P.id(studentId, 'student'));
  if (!student || !P.enrolled(student, subject) || String(student.class) !== String(subject.class)) P.fail('This student is not enrolled in your subject.', 403);
  const filter = { subject: subject._id, student: student._id, term };
  const update = { $set: { ...text, updatedBy: actor.userId } };
  try {
    await NarrativeReport.updateOne(filter, update, { upsert: true, runValidators: true });
  } catch (error) {
    if (error.code !== 11000) throw error;
    await NarrativeReport.updateOne(filter, update, { runValidators: true });
  }
  return { studentId, term, ...text };
}
function attendanceDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) ||
      !Number.isFinite(Date.parse(value)) || new Date(value).toISOString().slice(0, 10) !== value)
    P.fail('Select a valid attendance date.');
  return value;
}
async function attendance(actor, subjectId, date) {
  date = attendanceDate(date);
  const subject = await ownedSubject(actor, subjectId);
  const students = await Student.find(P.rosterFilter(subject)).sort({ lastName: 1, firstName: 1 });
  await Attendance.ensureTermIndex();
  const records = dailyAttendance(await Attendance.find({ subject: subject._id, date }));
  const statuses = new Map(records.map((record) => [String(record.student), record]));
  return { date, roster: students.map((student) => ({
    studentId: student._id, firstName: student.firstName, lastName: student.lastName,
    status: statuses.get(String(student._id))?.status || 'unmarked',
    term: statuses.get(String(student._id))?.term || null,
    recorded: statuses.has(String(student._id))
  })) };
}
async function saveAttendance(actor, subjectId, studentId, body) {
  const date = attendanceDate(body?.date);
  const term = null;
  if (!['unmarked', 'absent', 'present', 'tardy'].includes(body?.status)) P.fail('Select a valid attendance status.');
  const subject = await ownedSubject(actor, subjectId);
  const student = await Student.findById(P.id(studentId, 'student'));
  if (!student || !P.enrolled(student, subject)) P.fail('This student is not enrolled in your subject.', 403);
  await Attendance.ensureTermIndex();
  const filter = { subject: subject._id, student: student._id, date, term };
  const update = { $set: { status: body.status, term, updatedBy: actor.userId } };
  try {
    await Attendance.updateOne(filter, update, { upsert: true, runValidators: true });
  } catch (error) {
    if (error.code !== 11000) throw error;
    await Attendance.updateOne(filter, update, { runValidators: true });
  }
  return { studentId, date, term, status: body.status };
}
function reportGrade(subject, grade) {
  if (!subject?.activities?.length) return P.weightedGrade(grade?.scores);
  const source = grade?.activityScores;
  const scores = source instanceof Map ? Object.fromEntries(source) : source || {};
  const terms = [1, 2, 3].map((term) => TermGrades.calculate(subject.activities, scores, term).termGrade);
  if (terms.some((value) => value === null)) return null;
  return Number((terms.reduce((sum, value) => sum + value, 0) / 3).toFixed(2));
}

async function teacher(actor, session = null) {
  if (actor.role !== 'teacher') P.fail('Only teachers can use this workflow.', 403);
  const user = await User.findOne({ _id: actor.userId, role: 'teacher', isActive: true }).session(
    session
  );
  if (!user) P.fail('Your teaching account is unavailable.', 403);
  return user;
}
async function adviser(actor, session = null) {
  await teacher(actor, session);
  const classes = await Class.find({ adviser: actor.userId }).session(session);
  if (!classes.length)
    P.fail('Only a class adviser can manage student records or advisory grades.', 403);
  return classes;
}
async function ownedSubject(actor, subjectId, session = null) {
  await teacher(actor, session);
  const subject = await Subject.findById(P.id(subjectId, 'subject')).session(session);
  if (!subject) P.fail('Subject not found.', 404);
  if (String(subject.teacher) !== actor.userId) P.fail('This is not your assigned subject.', 403);
  return subject;
}
async function audit(actor, action, data, session) {
  await Audit.create([{ actor: actor.userId, action, ...data }], { session });
}
async function touch(subject, session, gradeChange = true) {
  subject.workflowRevision = (subject.workflowRevision || 0) + 1;
  if (gradeChange) subject.gradeVersion = (subject.gradeVersion || 0) + 1;
  await subject.save({ session });
}
async function roster(subject, session = null) {
  const students = await Student.find(P.rosterFilter(subject))
    .sort({ lastName: 1, firstName: 1 })
    .session(session);
  const grades = await Grade.find({
    subject: subject._id,
    student: { $in: students.map((s) => s._id) }
  }).session(session);
  const byStudent = new Map(grades.map((g) => [String(g.student), g]));
  return students.map((student) => {
    const source = byStudent.get(String(student._id))?.scores || {};
    const scores = Object.fromEntries(P.scoreFields.map((field) => [field, source[field] ?? null]));
    return {
      studentId: student._id,
      lrn: student.lrn || '',
      firstName: student.firstName,
      lastName: student.lastName,
      middleName: student.middleName || student.middleInitial || '',
      gender: student.gender,
      gradeLevel: student.gradeLevel || '',
      scores,
      weightedGrade: reportGrade(subject, byStudent.get(String(student._id))),
      activityScores: Object.fromEntries(byStudent.get(String(student._id))?.activityScores || [])
    };
  });
}
async function teacherRoster(actor, subjectId) {
  const subject = await ownedSubject(actor, subjectId);
  const editing = await GradingAccess.access(actor, subject);
  const rows = await roster(subject);
  rows.forEach((row) => {
    row.terms = Object.fromEntries([1, 2, 3].map((term) => [term,
      TermGrades.calculate(subject.activities || [], row.activityScores, term)
    ]));
  });
  const cls = await Class.findById(subject.class).populate('adviser', 'username');
  const requests = await EditRequest.find({ subject: subject._id })
    .populate('reviewedBy', 'username')
    .sort({ createdAt: -1 })
    .limit(10);
  const graded = rows.filter((row) => row.weightedGrade !== null);
  return {
    subjectId: subject._id,
    subjectName: subject.name,
    className: cls?.name || 'Class unavailable',
    adviserName: cls?.adviser?.username || '',
    canRequestEdit: editing.canRequest,
    canFinalize: Boolean(cls?.adviser),
    canEditGrades: editing.canEdit,
    gradingDeadline: editing.policy?.deadline || null,
    isSubjectHead: editing.isHead,
    subjectHeadAssigned: Boolean(editing.policy?.head),
    editPermissionGranted: editing.granted,
    gradeStatus: subject.gradeStatus || 'draft',
    gradeVersion: subject.gradeVersion || 0,
    finalizedAt: subject.finalizedAt,
    requests,
    totalStudents: rows.length,
    classAverage: graded.length
      ? Number((graded.reduce((sum, row) => sum + row.weightedGrade, 0) / graded.length).toFixed(1))
      : null,
    passingRate: graded.length
      ? Number(
          ((graded.filter((row) => row.weightedGrade >= 75).length / graded.length) * 100).toFixed(
            1
          )
        )
      : null,
    roster: rows,
    activities: subject.activities || []
  };
}
async function advisoryReportSubjects(actor) {
  await teacher(actor);
  const classes = await Class.find({ adviser: actor.userId }).session(null);
  return mySubjects(actor, classes.map((cls) => cls._id));
}
async function mySubjects(actor, advisoryClasses = null) {
  await teacher(actor);
  const subjects = await Subject.find(advisoryClasses ? { class: { $in: advisoryClasses } } : { teacher: actor.userId }).populate('class', 'name gradeLevel section');
  return Promise.all(
    subjects.map(async (subject) => {
      const filter = P.rosterFilter(subject);
      const [studentCount, studentGrades] = await Promise.all([
        Student.countDocuments(filter),
        Student.distinct('gradeLevel', filter)
      ]);
      return {
        _id: subject._id,
        name: subject.name,
        classId: subject.class?._id || null,
        className: subject.class?.name || 'Class unavailable',
        gradeLevel: subject.class?.gradeLevel || '',
        gradeLevels: [...new Set([subject.class?.gradeLevel, ...studentGrades]
          .filter((grade) => typeof grade === 'string' && grade.trim()))],
        section: subject.class?.section || subject.class?.name || '',
        gradeStatus: subject.gradeStatus || 'draft',
        studentCount
      };
    })
  );
}
function validateWSPercentage(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0 || value > 100)
    P.fail('WS Percentage must be greater than 0 and at most 100.');
  return value;
}
async function addActivity(actor, subjectId, body) {
  if (![1, 2, 3].includes(body?.term)) P.fail('Select a valid term.');
  if (!['writtenOral', 'performanceTasks', 'examination'].includes(body?.category))
    P.fail('Select a valid activity category.');
  const title = P.text(body?.title, 'activity title', 100);
  const wsPercentage = body.category === 'examination' ? validateWSPercentage(body.wsPercentage) : undefined;
  if (!Number.isInteger(body?.maxScore) || body.maxScore < 1 || body.maxScore > 10000)
    P.fail('Maximum score must be a whole number from 1 to 10000.');
  let result;
  await mongoose.connection.transaction(async (session) => {
    const subject = await ownedSubject(actor, subjectId, session);
    await GradingAccess.requireEditing(actor, subject, session);
    P.version(body.version, subject.gradeVersion);
    subject.activities ||= [];
    if (
      subject.activities.filter(
        (item) => item.term === body.term && item.category === body.category
      ).length >= 100
    )
      P.fail('This category already has 100 activities.');
    subject.activities.push({
      term: body.term,
      category: body.category,
      title,
      maxScore: body.maxScore,
      wsPercentage
    });
    await touch(subject, session);
    await audit(
      actor,
      'activity-added',
      {
        subject: subject._id,
        details: { term: body.term, category: body.category, title, maxScore: body.maxScore, wsPercentage }
      },
      session
    );
    result = { activities: subject.activities, gradeVersion: subject.gradeVersion };
  });
  return result;
}
async function changeActivity(actor, subjectId, activityId, body, remove = false) {
  activityId = P.id(activityId, 'activity');
  const title = remove ? null : P.text(body?.title, 'activity title', 100);
  if (!remove && (!Number.isInteger(body?.maxScore) || body.maxScore < 1 || body.maxScore > 10000))
    P.fail('Maximum score must be a whole number from 1 to 10000.');
  let result;
  await mongoose.connection.transaction(async (session) => {
    const subject = await ownedSubject(actor, subjectId, session);
    await GradingAccess.requireEditing(actor, subject, session);
    P.version(body?.version, subject.gradeVersion);
    const activity = subject.activities.id(activityId);
    if (!activity) P.fail('Activity not found. Reload the class.', 404);
    const before = activity.toObject();
    if (
      !remove &&
      body.maxScore < activity.maxScore &&
      (await Grade.exists({
        subject: subject._id,
        ['activityScores.' + activityId]: { $gt: body.maxScore }
      }).session(session))
    ) {
      P.fail(
        'Maximum points cannot be lower than an existing student score. Update those scores first.',
        409
      );
    }
    if (remove)
      await Grade.updateMany(
        { subject: subject._id },
        { $unset: { ['activityScores.' + activityId]: '' } },
        { session }
      );
    if (remove) activity.deleteOne();
    else {
      activity.title = title;
      activity.maxScore = body.maxScore;
      if (activity.category === 'examination' && body.wsPercentage !== undefined)
        activity.wsPercentage = validateWSPercentage(body.wsPercentage);
    }
    await touch(subject, session);
    await audit(
      actor,
      remove ? 'activity-deleted' : 'activity-updated',
      { subject: subject._id, details: { before, after: remove ? null : activity.toObject() } },
      session
    );
    result = { activities: subject.activities, gradeVersion: subject.gradeVersion };
  });
  return result;
}
async function reorderActivities(actor, subjectId, body) {
  if (![1, 2, 3].includes(body?.term) ||
      !['writtenOral', 'performanceTasks', 'examination'].includes(body?.category) ||
      !Array.isArray(body?.activityIds)) P.fail('Select a valid activity group and order.');
  const ids = body.activityIds.map((value) => P.id(value, 'activity'));
  let result;
  await mongoose.connection.transaction(async (session) => {
    const subject = await ownedSubject(actor, subjectId, session);
    await GradingAccess.requireEditing(actor, subject, session);
    P.version(body.version, subject.gradeVersion);
    const matches = (activity) => activity.term === body.term && activity.category === body.category;
    const current = subject.activities.filter(matches);
    const byId = new Map(current.map((activity) => [String(activity._id), activity.toObject()]));
    if (ids.length !== current.length || new Set(ids).size !== ids.length || ids.some((id) => !byId.has(id)))
      P.fail('The order must contain each activity in this group exactly once. Reload and try again.');
    const before = current.map((activity) => String(activity._id));
    if (ids.some((id, index) => id !== before[index])) {
      let index = 0;
      subject.activities = subject.activities.map((activity) => matches(activity) ? byId.get(ids[index++]) : activity.toObject());
      await touch(subject, session);
      await audit(actor, 'activities-reordered', {
        subject: subject._id, details: { term: body.term, category: body.category, before, after: ids }
      }, session);
    }
    result = { activities: subject.activities, gradeVersion: subject.gradeVersion };
  });
  return result;
}
async function saveActivityScores(actor, subjectId, body) {
  let gradeVersion;
  await mongoose.connection.transaction(async (session) => {
    const subject = await ownedSubject(actor, subjectId, session);
    await GradingAccess.requireEditing(actor, subject, session);
    P.version(body?.version, subject.gradeVersion);
    const students = await Student.find(P.rosterFilter(subject)).select('_id').session(session);
    const entries = P.validateActivityScores(
      body?.grades,
      students.map((student) => student._id),
      subject.activities || [],
      body?.term
    );
    const before = await Grade.find({
      subject: subject._id,
      student: { $in: entries.map((entry) => entry.studentId) }
    })
      .lean()
      .session(session);
    await touch(subject, session);
    for (const entry of entries) {
      const updates = { updatedBy: actor.userId };
      for (const [activityId, score] of Object.entries(entry.scores))
        updates['activityScores.' + activityId] = score;
      await Grade.findOneAndUpdate(
        { subject: subject._id, student: entry.studentId },
        { $set: updates },
        { session, upsert: true, runValidators: true }
      );
    }
    await audit(
      actor,
      'grades-saved',
      { subject: subject._id, details: { term: body.term, before, after: entries } },
      session
    );
    gradeVersion = subject.gradeVersion;
  });
  return { message: 'Activity scores saved.', gradeVersion };
}
async function saveGrades(actor, subjectId, body) {
  let gradeVersion;
  await mongoose.connection.transaction(async (session) => {
    const subject = await ownedSubject(actor, subjectId, session);
    await GradingAccess.requireEditing(actor, subject, session);
    P.version(body?.version, subject.gradeVersion);
    const students = await Student.find(P.rosterFilter(subject)).select('_id').session(session);
    const entries = P.validateGrades(
      body?.grades,
      students.map((s) => s._id)
    );
    const before = await Grade.find({
      subject: subject._id,
      student: { $in: entries.map((e) => e.studentId) }
    })
      .lean()
      .session(session);
    await touch(subject, session);
    for (const entry of entries) {
      await Grade.findOneAndUpdate(
        { student: entry.studentId, subject: subject._id },
        { $set: { scores: entry.scores, updatedBy: actor.userId } },
        { session, upsert: true, runValidators: true }
      );
    }
    await audit(
      actor,
      'grades-saved',
      { subject: subject._id, details: { before, after: entries } },
      session
    );
    gradeVersion = subject.gradeVersion;
  });
  return { message: 'Grades saved.', gradeVersion };
}
async function finalize(actor, subjectId, body) {
  await mongoose.connection.transaction(async (session) => {
    const subject = await ownedSubject(actor, subjectId, session);
    P.requireDraft(subject);
    P.version(body?.version, subject.gradeVersion);
    const cls = await Class.findById(subject.class).session(session);
    if (!cls?.adviser)
      P.fail('Ask the super admin to assign a class adviser before finalizing grades.', 409);
    const rows = await roster(subject, session);
    P.requireComplete(rows);
    subject.gradeStatus = 'finalized';
    subject.finalizedAt = new Date();
    subject.finalizedBy = actor.userId;
    subject.editPermission = undefined;
    await touch(subject, session);
    await audit(
      actor,
      'grades-finalized',
      { subject: subject._id, details: { gradeVersion: subject.gradeVersion, grades: rows } },
      session
    );
  });
  return { message: 'Grades finalized for reports.' };
}
async function requestEdit(actor, subjectId, body) {
  const reason = P.text(body?.reason, 'reason for reopening', 1000);
  await mongoose.connection.transaction(async (session) => {
    const subject = await ownedSubject(actor, subjectId, session);
    const state = await GradingAccess.access(actor, subject, session, true);
    if (!state.canRequest) P.fail('Edit requests are available only after the deadline, for teachers who need subject-head approval.', 409);
    P.version(body?.version, subject.gradeVersion);
    if (await EditRequest.exists({ subject: subject._id, status: 'pending' }).session(session))
      P.fail('An edit request is already pending for this subject.', 409);
    await touch(subject, session, false);
    const [request] = await EditRequest.create([{
      subject: subject._id, class: subject.class, requestedBy: actor.userId, reason,
      gradeVersion: subject.gradeVersion || 0, policyRevision: state.policy.revision,
      assignedHead: state.policy.head
    }], { session });
    await audit(actor, 'reopening-requested', { subject: subject._id, request: request._id, details: { reason } }, session);
  });
  return { message: 'Edit request sent to the subject head. Grades remain locked until approved.' };
}
async function requestsForAdviser(actor) {
  await teacher(actor);
  const policies = await SubjectLeadership.find({ head: actor.userId });
  const subjects = await Subject.find();
  const ids = subjects.filter((subject) => policies.some((policy) => policy.name === GradingAccess.key(subject.name))).map((s) => s._id);
  return EditRequest.find({ subject: { $in: ids } })
    .populate('subject', 'name gradeStatus').populate('class', 'name')
    .populate('requestedBy', 'username').populate('reviewedBy', 'username').sort({ createdAt: -1 });
}
async function myRequests(actor) {
  await teacher(actor);
  const subjects = await Subject.find({ teacher: actor.userId }).select('_id');
  return EditRequest.find({
    requestedBy: actor.userId,
    subject: { $in: subjects.map((subject) => subject._id) }
  })
    .populate('subject', 'name')
    .populate('class', 'name')
    .populate('reviewedBy', 'username')
    .sort({ createdAt: -1 });
}
async function teacherModificationHistory(actor) {
  await teacher(actor);
  const subjects = await Subject.find({ teacher: actor.userId }).select('_id');
  return Audit.find({ subject: { $in: subjects.map((subject) => subject._id) } })
    .select('action subject actor createdAt')
    .populate('subject', 'name')
    .populate('actor', 'username')
    .sort({ createdAt: -1 })
    .limit(100);
}
async function modificationHistory(actor) {
  const classes = await adviser(actor);
  const subjects = await Subject.find({
    $or: [{ class: { $in: classes.map((cls) => cls._id) } }, { teacher: actor.userId }]
  }).select('_id');
  return Audit.find({ subject: { $in: subjects.map((subject) => subject._id) } })
    .select('action subject actor createdAt')
    .populate('subject', 'name')
    .populate('actor', 'username')
    .sort({ createdAt: -1 })
    .limit(100);
}
async function reviewRequest(actor, requestId, body) {
  P.id(requestId, 'edit request');
  if (!['approved', 'rejected'].includes(body?.decision)) P.fail('Choose approve or reject.');
  const note = P.text(body.note, 'review note', 1000, true);
  await mongoose.connection.transaction(async (session) => {
    await teacher(actor, session);
    const request = await EditRequest.findById(requestId).session(session);
    if (!request) P.fail('Edit request not found.', 404);
    const subject = await Subject.findById(request.subject).session(session);
    if (!subject) P.fail('Subject not found.', 404);
    const state = await GradingAccess.access(actor, subject, session, true);
    if (!state.isHead) P.fail('Only the assigned subject head may review this request.', 403);
    if (request.status !== 'pending') P.fail('This request has already been reviewed.', 409);
    if (body.decision === 'approved') {
      if (
        !state.expired || request.policyRevision !== state.policy.revision ||
        subject.gradeVersion !== request.gradeVersion ||
        String(subject.teacher) !== String(request.requestedBy)
      ) {
        P.fail(
          'This request is outdated. Reject it and ask the current subject teacher to send a new request.',
          409
        );
      }
      subject.editPermission = { teacher: subject.teacher, policyRevision: state.policy.revision };
      subject.gradeStatus = 'draft';
      subject.finalizedAt = null;
      subject.finalizedBy = null;
    }
    await touch(subject, session, body.decision === 'approved');
    request.status = body.decision;
    request.reviewNote = note;
    request.reviewedBy = actor.userId;
    request.reviewedAt = new Date();
    await request.save({ session });
    await audit(
      actor,
      'reopening-' + body.decision,
      { subject: subject._id, request: request._id, details: { note } },
      session
    );
  });
  return {
    message:
      body.decision === 'approved'
        ? 'Request approved. The subject teacher can edit and must finalize again.'
        : 'Request rejected. Grades remain locked.'
  };
}
async function studentOptions(actor) {
  await adviser(actor);
  const classes = await Class.find().populate('adviser', 'username').sort({ name: 1 });
  const subjects = await Subject.find().populate('teacher', 'username').sort({ name: 1 });
  const rosterGrades = await Student.aggregate([
    { $group: { _id: { classId: '$class', gradeLevel: '$gradeLevel' } } }
  ]);
  return { classes, subjects, rosterGrades: rosterGrades.map((row) => row._id) };
}
async function listStudents(actor, query) {
  await adviser(actor);
  const filter = {};
  if (query.gender) {
    if (!['Male', 'Female'].includes(query.gender)) P.fail('Select a valid gender filter.');
    filter.gender = query.gender;
  }
  if (query.classId) filter.class = P.id(query.classId, 'class');
  if (query.gradeLevel) {
    const gradeLevel = P.text(query.gradeLevel, 'grade level', 40);
    const classes = await Class.find({ gradeLevel }).select('_id');
    filter.$and = [
      {
        $or: [
          { gradeLevel },
          { gradeLevel: { $in: ['', null] }, class: { $in: classes.map((cls) => cls._id) } }
        ]
      }
    ];
  }
  if (query.subjectId) {
    const subject = await Subject.findById(P.id(query.subjectId, 'subject'));
    if (!subject) P.fail('Subject not found.', 404);
    filter.$and = [...(filter.$and || []), P.rosterFilter(subject)];
  }
  const search = P.text(query.q, 'search', 100, true);
  if (search) {
    const regex = new RegExp(search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    filter.$or = ['lrn', 'firstName', 'lastName', 'middleName'].map((field) => ({
      [field]: regex
    }));
  }
  const page = Math.max(1, Number.parseInt(query.page, 10) || 1);
  const limit = 25;
  const total = await Student.countDocuments(filter);
  const students = await Student.find(filter)
    .populate('class', 'name gradeLevel section')
    .collation({ locale: 'en', strength: 2 })
    .sort({ lastName: 1, firstName: 1, _id: 1 })
    .skip((page - 1) * limit)
    .limit(limit)
    .lean();
  const subjects = await Subject.find({
    class: { $in: students.map((student) => student.class?._id).filter(Boolean) }
  }).select('_id class');
  students.forEach((student) => {
    if (student.subjects === undefined)
      student.subjects = subjects
        .filter((subject) => String(subject.class) === String(student.class?._id))
        .map((subject) => subject._id);
    student.recordVersion = student.recordVersion || 0;
  });
  return { students, total, page, pages: Math.max(1, Math.ceil(total / limit)) };
}
async function saveStudent(actor, studentId, body) {
  const input = {
    lrn: P.text(body?.lrn, 'LRN', 30),
    firstName: P.text(body?.firstName, 'first name'),
    lastName: P.text(body?.lastName, 'last name'),
    middleName: P.text(body?.middleName, 'middle name', 100, true),
    gradeLevel: P.text(body?.gradeLevel, 'grade level', 40),
    class: P.id(body?.classId, 'class')
  };
  if (!/^\d+$/.test(input.lrn)) P.fail('LRN must contain digits only.');
  if (!['Male', 'Female'].includes(body.gender)) P.fail('Select a gender.');
  input.gender = body.gender;
  if (!Array.isArray(body.subjectIds)) P.fail('Select the student’s subjects.');
  input.subjects = [...new Set(body.subjectIds.map((value) => P.id(value, 'subject')))];
  if (studentId) P.id(studentId, 'student');
  let savedId;
  await mongoose.connection.transaction(async (session) => {
    await adviser(actor, session);
    const cls = await Class.findById(input.class).session(session);
    if (!cls) P.fail('Class not found.', 404);
    // Serialize enrollment with an admin clearing this section.
    await Class.updateOne({ _id: cls._id }, { $inc: { __v: 1 } }, { session });
    if (cls.gradeLevel && cls.gradeLevel !== input.gradeLevel)
      P.fail('Grade level must match the selected class.');
    let student = studentId ? await Student.findById(studentId).session(session) : null;
    if (studentId && !student) P.fail('Student not found.', 404);
    if (student) P.version(body.version, student.recordVersion);
    if (
      await Student.exists({
        lrn: input.lrn,
        ...(studentId ? { _id: { $ne: studentId } } : {})
      }).session(session)
    )
      P.fail('A student with this LRN already exists.', 409);
    const selected = await Subject.find({
      _id: { $in: input.subjects },
      class: input.class
    }).session(session);
    if (selected.length !== input.subjects.length)
      P.fail('Select subjects belonging to the selected class and section.');
    const oldSubjects = !student
      ? []
      : student.subjects === undefined
        ? (await Subject.find({ class: student.class }).session(session)).map((subject) =>
            String(subject._id)
          )
        : student.subjects.map(String);
    const changed = [...new Set([...oldSubjects, ...input.subjects])].filter(
      (value) => oldSubjects.includes(value) !== input.subjects.includes(value)
    );
    const affected = await Subject.find({ _id: { $in: changed } }).session(session);
    for (const subject of affected) {
      if (subject.gradeStatus === 'finalized')
        P.fail(
          'Enrollment for ' +
            subject.name +
            ' is locked. Its subject teacher must request reopening before changing this placement.',
          409
        );
      await touch(subject, session);
    }
    const before = student?.toObject() || null;
    if (!student) student = new Student(input);
    else Object.assign(student, input);
    student.middleInitial = input.middleName ? input.middleName[0] : '';
    student.updatedBy = actor.userId;
    student.recordVersion = (student.recordVersion || 0) + 1;
    await student.save({ session });
    savedId = student._id;
    await audit(
      actor,
      studentId ? 'student-updated' : 'student-registered',
      { student: student._id, details: { before, after: student.toObject() } },
      session
    );
  });
  return {
    message: studentId ? 'Student record and enrollment updated.' : 'Student registered.',
    studentId: savedId
  };
}
async function monitor(actor) {
  const classes = await adviser(actor);
  const classIds = classes.map((cls) => cls._id);
  const subjects = await Subject.find({ class: { $in: classIds } }).populate('teacher', 'username');
  const students = await Student.find({ class: { $in: classIds } }).sort({
    lastName: 1,
    firstName: 1
  });
  const grades = await Grade.find({
    subject: { $in: subjects.map((s) => s._id) },
    student: { $in: students.map((s) => s._id) }
  });
  const lookup = new Map(
    grades.map((grade) => [
      String(grade.student) + ':' + String(grade.subject),
      reportGrade(subjects.find((subject) => String(subject._id) === String(grade.subject)), grade)
    ])
  );
  const subjectSummaries = subjects.map((subject) => {
    const enrolledStudents = students.filter((student) => P.enrolled(student, subject));
    return {
      _id: subject._id,
      name: subject.name,
      className: classes.find((cls) => String(cls._id) === String(subject.class))?.name,
      teacherName: subject.teacher?.username || 'Not assigned',
      status: subject.gradeStatus || 'draft',
      total: enrolledStudents.length,
      complete: enrolledStudents.filter(
        (student) => lookup.get(String(student._id) + ':' + String(subject._id)) != null
      ).length
    };
  });
  const reportSource = await SF9.source(students.map((s) => s._id), subjects.map((s) => s._id));
  const studentSummaries = students.map((student) => {
    const supplement = SF9.build(student, subjects.filter((subject) => P.enrolled(student, subject)), reportSource);
    const entries = subjects
      .filter((subject) => P.enrolled(student, subject))
      .map((subject) => ({
        subjectId: subject._id,
        name: subject.name,
        grade: lookup.get(String(student._id) + ':' + String(subject._id)) ?? null,
        status: subject.gradeStatus || 'draft'
      }));
    return {
      studentId: student._id,
      lrn: student.lrn || '',
      name: student.lastName + ', ' + student.firstName,
      className: classes.find((cls) => String(cls._id) === String(student.class))?.name,
      subjects: entries,
      reportMissing: supplement.missing,
      readyForReport:
        !supplement.missing.length && entries.length > 0 &&
        entries.every((entry) => entry.grade !== null && entry.status === 'finalized')
    };
  });
  return {
    classes,
    subjects: subjectSummaries,
    students: studentSummaries,
    pendingRequests: await EditRequest.countDocuments({
      class: { $in: classIds },
      status: 'pending'
    })
  };
}
async function finalReport(actor, studentId) {
  // Read one snapshot so a concurrent reopening cannot mix draft scores into a final report.
  return mongoose.connection.transaction(
    async (session) => {
      const classes = await adviser(actor, session);
      const student = await Student.findOne({
        _id: P.id(studentId, 'student'),
        class: { $in: classes.map((cls) => cls._id) }
      })
        .session(session)
        .lean();
      if (!student) P.fail('This student is not in your advisory class.', 403);
      const cls = classes.find((item) => String(item._id) === String(student.class));
      const subjects = await Subject.find({ class: student.class }).session(session);
      const included = subjects.filter((subject) => P.enrolled(student, subject));
      if (!included.length)
        P.fail('Enroll this student in subjects before generating a final report.', 409);
      const grades = await Grade.find({
        student: student._id,
        subject: { $in: included.map((subject) => subject._id) }
      }).session(session);
      const supplement = SF9.build(student, included, await SF9.source([student._id], included.map((s) => s._id), session));
      if (supplement.missing.length) P.fail('SF9 is incomplete: ' + supplement.missing.join(' '), 409);
      const entries = included.map((subject) => ({
        subjectId: String(subject._id),
        name: subject.name,
        terms: [1, 2, 3].map((term) => {
          const grade = grades.find((item) => String(item.subject) === String(subject._id));
          const scores = grade?.activityScores instanceof Map ? Object.fromEntries(grade.activityScores) : grade?.activityScores || {};
          return TermGrades.calculate(subject.activities || [], scores, term).termGrade;
        }),
        grade: reportGrade(subject,
          grades.find((grade) => String(grade.subject) === String(subject._id))
        ),
        status: subject.gradeStatus || 'draft'
      }));
      if (entries.some((entry) => entry.status !== 'finalized' || entry.grade === null))
        P.fail(
          'Final reports are available only when every enrolled subject is complete and finalized.',
          409
        );
      const user = await User.findById(actor.userId).select('username').session(session);
      return {
        student,
        className: cls.name,
        adviserName: user.username,
        ...supplement,
        gradeLevel: student.gradeLevel || cls.gradeLevel || '',
        section: cls.section || cls.name,
        subjects: entries,
        generalAverage: Number(
          (entries.reduce((sum, entry) => sum + entry.grade, 0) / entries.length).toFixed(2)
        ),
        generatedAt: new Date()
      };
    },
    { readConcern: { level: 'snapshot' } }
  );
}
async function insights(actor, subjectId) {
  const data = await teacherRoster(actor, subjectId);
  const distribution = { A: 0, B: 0, C: 0, F: 0, notGraded: 0 };
  const atRisk = [];
  data.roster.forEach((row) => {
    const grade = row.weightedGrade;
    distribution[
      grade === null ? 'notGraded' : grade >= 90 ? 'A' : grade >= 80 ? 'B' : grade >= 75 ? 'C' : 'F'
    ]++;
    if (grade !== null && grade < 75)
      atRisk.push({
        studentId: row.studentId,
        name: row.firstName + ' ' + row.lastName,
        weightedGrade: grade
      });
  });
  const componentAverages = Object.fromEntries(
    P.scoreFields.map((field) => {
      const values = data.roster.map((row) => row.scores[field]).filter((value) => value !== null);
      return [
        field,
        values.length
          ? Number((values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(1))
          : null
      ];
    })
  );
  return {
    ...data,
    distribution,
    componentAverages,
    atRisk: atRisk.sort((a, b) => a.weightedGrade - b.weightedGrade)
  };
}
module.exports = {
  coreValueReports,
  saveCoreValues,
  narrativeReports,
  saveNarrativeReport,
  attendance,
  saveAttendance,
  adviser,
  teacherRoster,
  mySubjects,
  advisoryReportSubjects,
  saveActivityScores,
  addActivity,
  changeActivity,
  reorderActivities,
  saveGrades,
  finalize,
  requestEdit,
  requestsForAdviser,
  reviewRequest,
  studentOptions,
  listStudents,
  saveStudent,
  monitor,
  finalReport,
  insights,
  myRequests,
  modificationHistory,
  teacherModificationHistory
};
