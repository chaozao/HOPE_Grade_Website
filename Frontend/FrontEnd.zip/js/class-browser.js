window.ClassBrowser = (function () {
  const termColumns = [
    'LRN',
    'Full Names',
    'Written / Oral Works',
    'Product / Performance Tasks',
    'Examination',
    'Initial Grade',
    'Term Grade',
    'Descriptor'
  ];
  const categories = [
    ['writtenOral', 'Written / Oral Works'],
    ['performanceTasks', 'Product / Performance Tasks'],
    ['examination', 'Examination']
  ];
  // WS WEIGHTS: Written / Oral Works = 20%, Product / Performance Tasks = 60%.
  // Keep these numeric for calculations; the table header adds the % sign below.
  const categoryWeights = { writtenOral: 20, performanceTasks: 60, examination: 20 };
  const finalColumns = [
    'Learners Name',
    '1st Term',
    '2nd Term',
    '3rd Term',
    'Final Grade',
    'Descriptor',
    'Remarks'
  ];
  const fullName = (student) =>
    [student.lastName + ',', student.firstName, student.middleName].filter(Boolean).join(' ');
  function finalAverage(terms) {
    const grades = [1, 2, 3].map((term) => terms[term]?.termGrade);
    if (
      grades.some(
        (grade) => typeof grade !== 'number' || !Number.isFinite(grade) || grade < 0 || grade > 100
      )
    )
      return null;
    return grades.reduce((sum, grade) => sum + grade, 0) / 3;
  }
  function create(root) {
    const UI = AcademicUI;
    let subjects = [],
      selected = null,
      data = null,
      version = 0;
    const scoreDrafts = new Map();
    window.addEventListener?.('beforeunload', (event) => {
      if (scoreDrafts.size) {
        event.preventDefault();
        event.returnValue = '';
      }
    });
    let reminder, replayNavigation = false;
    function remindBeforeLeaving(leave) {
      if (!scoreDrafts.size) { leave(); return; }
      if (!reminder) {
        reminder = UI.node('dialog', undefined, 'workflow-dialog grade-save-reminder');
        reminder.setAttribute('aria-label', 'Unsaved grades');
        document.body.appendChild(reminder);
      }
      reminder.replaceChildren(UI.node('h2', 'Please save your grades'), UI.node('p', 'You have unsaved scores. Click Keep editing, then Save scores before leaving this class.'));
      const actions = UI.node('div', undefined, 'workflow-toolbar');
      actions.append(UI.button('Keep editing', () => reminder.close()), UI.button('Leave without saving', () => { reminder.close(); leave(); }));
      reminder.appendChild(actions); reminder.showModal();
    }
    document.addEventListener?.('click', (event) => {
      if (replayNavigation || !scoreDrafts.size || root.closest?.('[hidden]')) return;
      const link = event.target.closest?.('a[href], #logout-btn');
      if (!link || root.contains(link)) return;
      event.preventDefault(); event.stopImmediatePropagation();
      remindBeforeLeaving(() => { replayNavigation = true; link.click(); replayNavigation = false; });
    }, true);
    const overview = UI.node('div'),
      detail = UI.node('div');
    const status = UI.node('p', '', 'workflow-status');
    status.id = 'class-browser-status';
    status.setAttribute('role', 'status');
    status.hidden = true;
    const retry = UI.button('Retry loading class', () =>
      selected ? openSubject(selected) : show()
    );
    retry.id = 'class-browser-retry';
    retry.hidden = true;
    root.append(status, retry, overview, detail);
    function message(text = '', error = false) {
      status.textContent = text;
      status.hidden = !text;
      status.classList.toggle('is-error', error);
      retry.hidden = !error;
    }
    function table(container, title, columns, id, groups) {
      const section = UI.node('section', undefined, 'grades-table-section class-browser-table');
      const heading = UI.node('div', undefined, 'table-header');
      heading.appendChild(UI.node('h2', title));
      const scroll = UI.node('div', undefined, 'class-table-scroll');
      scroll.tabIndex = 0;
      scroll.setAttribute('role', 'region');
      scroll.setAttribute('aria-label', title);
      const grid = UI.node('table', undefined, 'grades-table'),
        head = UI.node('thead'),
        header = UI.node('tr'),
        body = UI.node('tbody');
      body.id = id;
      if (id === 'class-grades-tbody' && !groups) grid.className = 'grades-table final-grades-table';
      if (groups) {
        const numbers = UI.node('tr'),
          maxima = UI.node('tr');
        columns.forEach((label, index) => {
          const cell = UI.node('th', label);
          header.appendChild(cell);
          if (index < 2 || index > 4) {
            cell.rowSpan = 3;
            cell.scope = 'col';
            return;
          }
          const group = groups[index - 2];
          cell.scope = 'colgroup';
          cell.colSpan = Math.max(1, group.activities.length) + (group.examination ? group.activities.length + 2 : 3);
          cell.className = 'activity-group-heading';
          const add = UI.button('+ Add column', group.add);
          add.disabled = group.locked;
          add.setAttribute('aria-label', 'Add activity to ' + label);
          const groupTitle = UI.node('div', undefined, 'activity-group-toolbar');
          groupTitle.append(UI.node('span', label), add);
          cell.replaceChildren(groupTitle);
          const items = group.activities.length ? group.activities : [null];
          items.forEach((activity, number) => {
            const numbered = UI.node(
              'th',
              activity ? (group.examination ? activity.title : String(number + 1)) : '\u2014',
              'activity-number'
            );
            numbered.scope = 'col';
            numbered.title = activity?.title || 'No activities yet';
            if (activity && !group.examination) {
              numbered.appendChild(UI.node('span', activity.title, 'activity-title'));
            }
            numbers.appendChild(numbered);
            // Generates <th class="activity-max" title="Maximum points">...</th>.
            // The number comes from the saved activity, not a fixed score in this file.
            const max = UI.node(
              'th',
              activity ? String(activity.maxScore) : '\u2014',
              'activity-max'
            );
            max.title = 'Maximum points';
            maxima.appendChild(max);
          });
          if (group.examination) {
            group.activities.forEach((activity) => {
              const weighted = UI.node('th', 'WS ' + activity.title, 'activity-weighted-header');
              weighted.scope = 'col';
              numbers.appendChild(weighted);
              maxima.appendChild(UI.node('th', activity.wsPercentage ?? '\u2014', 'activity-max activity-weighted-header'));
            });
          }
          if (group.summary) {
            (group.examination ? ['PS', 'WS'] : ['Total', 'PS', 'WS']).forEach((label, index) => {
              const heading = UI.node('th', label, 'activity-number activity-summary');
              heading.scope = 'col';
              heading.title = ({ Total: 'Total points', PS: 'Percentage Score', WS: 'Weighted Score' })[label];
              numbers.appendChild(heading);
              // SUMMARY MAXIMUM HEADERS: Total = sum of activity limits, PS = 100,
              // WS = the configured percentage, displayed as "20%" or "60%".
              const weightedScoreMaximum = group.weight === null ? '\u2014' : group.weight + '%';
              const value = ({ Total: group.maximum, PS: 100, WS: weightedScoreMaximum })[label];
              maxima.appendChild(UI.node('th', String(value), 'activity-max activity-summary'));
            });
          }
        });
        head.append(header, numbers, maxima);
      } else {
        columns.forEach((label) => {
          const cell = UI.node('th', label);
          cell.scope = 'col';
          header.appendChild(cell);
        });
        head.appendChild(header);
      }
      grid.append(head, body);
      scroll.appendChild(grid);
      section.append(heading, scroll);
      container.appendChild(section);
      return body;
    }
    async function show() {
      selected = null;
      data = null;
      const request = ++version;
      overview.hidden = false;
      detail.hidden = true;
      overview.replaceChildren();
      message(subjects.length ? 'Loading subjects…' : '');
      const body = table(
        overview,
        'Subject Overview',
        ['Subject', 'Class and Section', 'Total of Students', 'Passing Rate'],
        'class-subjects-tbody'
      );
      if (!subjects.length) {
        UI.empty(body, 'No teaching assignments available.', 4);
        return;
      }
      const results = await Promise.allSettled(
        subjects.map((subject) =>
          UI.api('/teacher/subjects/' + encodeURIComponent(subject._id) + '/roster')
        )
      );
      if (request !== version) return;
      let failed = false;
      subjects.forEach((subject, index) => {
        const result = results[index];
        const roster = result.status === 'fulfilled' ? result.value : null;
        failed ||= !roster;
        const name = UI.node('div'),
          link = UI.node('a', subject.name, 'class-subject-link');
        link.href = '#class';
        link.addEventListener('click', (event) => {
          event.preventDefault();
          openSubject(subject);
        });
        name.appendChild(link);
        UI.row(body, [
          name,
          subject.className || '—',
          roster ? roster.totalStudents : (subject.studentCount ?? '—'),
          roster
            ? roster.passingRate == null
              ? 'Not graded'
              : roster.passingRate + '%'
            : 'Unavailable'
        ]);
      });
      const note = UI.node(
        'p',
        'Passing rate is based on available recorded grades (75 and above).',
        'table-footnote'
      );
      overview.appendChild(note);
      message(failed ? 'Some grade summaries could not load. Retry to refresh them.' : '', failed);
    }
    async function openSubject(subject) {
      selected = subject;
      data = null;
      const request = ++version;
      overview.hidden = true;
      detail.hidden = false;
      detail.replaceChildren();
      const deadlinePassed = () => Boolean(data?.gradingDeadline && Date.now() >= new Date(data.gradingDeadline).getTime());
      const gradesLocked = () => data?.canEditGrades === undefined ? data?.gradeStatus === 'finalized'
        : !data.canEditGrades || (deadlinePassed() && !data.isSubjectHead && !data.editPermissionGranted);
      function scheduleDeadline() {
        if (!window.setTimeout || !data?.gradingDeadline || data.isSubjectHead || data.editPermissionGranted || deadlinePassed()) return;
        const delay = Math.min(2147483647, Math.max(1, new Date(data.gradingDeadline).getTime() - Date.now() + 10));
        window.setTimeout(function checkDeadline() {
          if (request !== version) return;
          if (saving) { window.setTimeout(checkDeadline, 500); return; }
          if (deadlinePassed()) { dialog.close(); render(); }
          else scheduleDeadline();
        }, delay);
      }
      let scoreInputs = [];
      let rosterPage = 1;
      const rosterPageSize = 8;
      const toolbar = UI.node('div', undefined, 'workflow-toolbar');
      const back = UI.button('', () => remindBeforeLeaving(show));
      back.className += ' class-back-button';
      back.setAttribute('aria-label', 'Back to subjects');
      back.title = 'Back to subjects';
      const arrow = UI.node('i', undefined, 'bi bi-arrow-left-square');
      arrow.setAttribute('aria-hidden', 'true');
      back.appendChild(arrow);
      toolbar.appendChild(back);
      const label = UI.node('label', 'Grading period '),
        select = UI.node('select');
      select.id = 'class-term-select';
      ['1st Term', '2nd Term', '3rd Term', 'Final Grades'].forEach((name, index) =>
        select.appendChild(new Option(name, String(index + 1)))
      );
      label.appendChild(select);
      detail.appendChild(toolbar);
      const manage = UI.button('Manage columns', manageColumns);
      manage.disabled = true;
      const toolbarActions = UI.node('div', undefined, 'class-toolbar-actions');
      toolbarActions.append(manage, label);
      const requestEdit = UI.button('Request grade edit', async () => {
        const reason = window.prompt('Explain why you need to edit grades after the deadline:');
        if (!reason?.trim()) return;
        requestEdit.disabled = true;
        try {
          await UI.api('/teacher/subjects/' + encodeURIComponent(subject._id) + '/edit-requests', {
            method: 'POST', body: JSON.stringify({ version: data.gradeVersion || 0, reason: reason.trim() })
          });
          await openSubject(subject);
          message('Edit request sent to your subject head.');
        } catch (error) { message(error.message, true); requestEdit.disabled = false; }
      });
      requestEdit.hidden = true;
      toolbarActions.appendChild(requestEdit);
      const deadlineNote = UI.node('p', '', 'workflow-status');
      detail.appendChild(deadlineNote);

      const finalizeButton = UI.button('Finalize grades', async () => {
        if (finalizeButton.disabled || saving) return;
        if (!window.confirm('Finalize all three terms for this subject? Later edits will return it to draft; deadlines still apply.')) return;
        saving = true;
        finalizeButton.disabled = true;
        select.disabled = back.disabled = true;
        try {
          await UI.api('/teacher/subjects/' + encodeURIComponent(subject._id) + '/finalize', {
            method: 'POST', body: JSON.stringify({ version: data.gradeVersion || 0 })
          });
          data = await UI.api('/teacher/subjects/' + encodeURIComponent(subject._id) + '/roster');
          render();
          message('Grades finalized. The class adviser can generate a final report once all enrolled subjects are finalized.');
        } catch (error) {
          message(error.message, true);
        } finally {
          saving = false;
          select.disabled = back.disabled = false;
          refreshScoreControls();
        }
      });
      finalizeButton.id = 'finalize-activity-grades';
      finalizeButton.hidden = true;
      toolbarActions.appendChild(finalizeButton);
      toolbar.appendChild(toolbarActions);
      const dialog = UI.node('dialog', undefined, 'activity-dialog');
      dialog.setAttribute('aria-labelledby', 'activity-editor-title');
      const editor = UI.node('form', undefined, 'activity-editor');
      editor.noValidate = true;
      const manager = UI.node('form', undefined, 'activity-manager');
      manager.hidden = true;
      dialog.append(manager, editor);
      detail.appendChild(dialog);
      const editorTitle = UI.node('h3'),
        titleLabel = UI.node('label', 'Activity name'),
        titleInput = UI.node('input');
      editorTitle.id = 'activity-editor-title';
      titleInput.required = true;
      titleInput.maxLength = 100;
      titleLabel.appendChild(titleInput);
      const maxLabel = UI.node('label', 'Maximum points'),
        maxInput = UI.node('input');
      Object.assign(maxInput, {
        type: 'number',
        min: '1',
        max: '10000',
        step: '1',
        required: true
      });
      maxLabel.appendChild(maxInput);
      const wsLabel = UI.node('label', 'WS Percentage'), wsInput = UI.node('input');
      Object.assign(wsInput, { type: 'number', min: '0.01', max: '100', step: '0.01' });
      wsInput.id = 'activity-ws-percentage';
      wsLabel.appendChild(wsInput);
      wsLabel.hidden = true;
      wsInput.disabled = true;
      const save = UI.node('button', 'Add activity', 'filter-btn');
      save.type = 'submit';
      const cancel = UI.button('Cancel', () => {
        dialog.close();
      });
      const editorStatus = UI.node('p');
      editorStatus.setAttribute('role', 'status');
      const remove = UI.button('Delete column', () => persist(true));
      remove.className += ' activity-delete';
      const footer = UI.node('div', undefined, 'activity-editor-footer'),
        actions = UI.node('div', undefined, 'activity-editor-actions');
      actions.append(cancel, save);
      footer.append(actions);
      editor.append(editorTitle, titleLabel, maxLabel, wsLabel, editorStatus, footer);
      let editingCategory = '',
        editingActivity = null,
        saving = false;
      dialog.addEventListener('cancel', (event) => {
        if (saving) event.preventDefault();
      });
      function outsideDialog(event) {
        const bounds = dialog.getBoundingClientRect();
        return (
          event.target === dialog &&
          (event.clientX < bounds.left ||
            event.clientX > bounds.right ||
            event.clientY < bounds.top ||
            event.clientY > bounds.bottom)
        );
      }
      let pressedOutside = false;
      dialog.addEventListener('pointerdown', (event) => {
        pressedOutside = outsideDialog(event);
      });
      dialog.addEventListener('click', (event) => {
        if (!saving && pressedOutside && outsideDialog(event)) dialog.close();
        pressedOutside = false;
      });
      function manageColumns(initialCategory = '') {
        if (!data || saving || select.value === '4') return;
        dialog.classList.toggle('managing-columns', true);
        editor.hidden = true;
        manager.hidden = false;
        manager.replaceChildren();
        const title = UI.node('h3', 'Manage columns');
        title.id = 'activity-manager-title';
        dialog.setAttribute('aria-labelledby', title.id);
        manager.append(
          title,
          UI.node(
            'p',
            select.selectedOptions[0].textContent +
              ' activities. Changes and deletions apply only when you save. Use Undo or Cancel to discard them.',
            'content-subtitle'
          )
        );
        const refreshUndo = [];
        const drafts = [],
          controls = [];
        const categoryLabel = UI.node('label', 'Activity category', 'activity-manager-category');
        const categorySelect = UI.node('select');
        categorySelect.id = 'activity-manager-category';
        const placeholder = new Option('Choose an activity category', '');
        placeholder.disabled = true;
        categorySelect.appendChild(placeholder);
        categories.forEach(([key, label]) => {
          categorySelect.appendChild(new Option(key === 'examination' ? 'Examinations' : label, key));
        });
        categorySelect.value = '';
        categoryLabel.appendChild(categorySelect);
        manager.appendChild(categoryLabel);
        controls.push(categorySelect);
        const sections = new Map();
        const orders = new Map();
        function moveActivity(draft, targetIndex) {
          if (saving || locked || draft.deleted) return;
          const order = orders.get(draft.category);
          const from = order.indexOf(draft.id);
          if (targetIndex < 0 || targetIndex >= order.length || targetIndex === from) return;
          order.splice(from, 1);
          order.splice(targetIndex, 0, draft.id);
          const section = sections.get(draft.category);
          order.forEach((id, index) => {
            const item = drafts.find((entry) => entry.id === id);
            section.appendChild(item.row);
            item.nameLabel.firstChild.textContent = (index + 1) + '. Activity name';
          });
          managerStatus.textContent = 'Order changed. Click Save changes to apply it.';
        }
        function showCategory(key) {
          categorySelect.value = key;
          sections.forEach((section, category) => { section.hidden = category !== key; });
          commit.hidden = !key;
        }
        categorySelect.addEventListener('change', () => showCategory(categorySelect.value));
        const locked = gradesLocked();
        categories.forEach(([key, label]) => {
          const activities = (data.activities || []).filter(
            (item) => item.term === Number(select.value) && item.category === key
          );
          const section = UI.node('section', undefined, 'activity-manager-group');
          orders.set(key, activities.map((activity) => activity._id));
          sections.set(key, section);
          section.hidden = key !== categorySelect.value;
          section.appendChild(UI.node('h4', label));
          if (!activities.length)
            section.appendChild(UI.node('p', 'No columns yet.', 'content-subtitle'));
          activities.forEach((activity, index) => {
            const row = UI.node('div', undefined, 'activity-manager-row');
            const info = UI.node('div', undefined, 'activity-manager-info');
            const nameLabel = UI.node('label', index + 1 + '. Activity name'),
              nameInput = UI.node('input');
            Object.assign(nameInput, {
              value: activity.title,
              required: true,
              maxLength: 100,
              disabled: locked
            });
            nameLabel.appendChild(nameInput);
            const pointsLabel = UI.node('label', 'Maximum points'),
              pointsInput = UI.node('input');
            Object.assign(pointsInput, {
              type: 'number',
              value: String(activity.maxScore),
              min: '1',
              max: '10000',
              step: '1',
              required: true,
              disabled: locked
            });
            pointsLabel.appendChild(pointsInput);
            info.append(nameLabel, pointsLabel);
            let weightInput;
            if (key === 'examination') {
              const weightLabel = UI.node('label', 'WS Percentage');
              weightInput = UI.node('input');
              Object.assign(weightInput, {
                type: 'number', min: '0.01', max: '100', step: '0.01', required: true,
                value: activity.wsPercentage === undefined ? '' : String(activity.wsPercentage), disabled: locked
              });
              weightLabel.appendChild(weightInput);
              info.appendChild(weightLabel);
              controls.push(weightInput);
            }
            const draft = { id: activity._id, category: key, row, nameLabel, nameInput, pointsInput, weightInput, deleted: false };
            drafts.push(draft);
            const handle = UI.button('\u2630', () => {});
            handle.className += ' activity-drag-handle';
            handle.title = 'Drag to reorder, or use the Up and Down arrow keys';
            handle.setAttribute('aria-label', 'Reorder ' + activity.title);
            handle.disabled = locked;
            controls.push(handle);
            handle.addEventListener('keydown', (event) => {
              if (!['ArrowUp', 'ArrowDown'].includes(event.key)) return;
              event.preventDefault();
              moveActivity(draft, orders.get(key).indexOf(draft.id) + (event.key === 'ArrowUp' ? -1 : 1));
              handle.focus();
            });
            let dragging = false;
            handle.addEventListener('pointerdown', (event) => {
              if (saving || locked || draft.deleted || event.button !== 0) return;
              dragging = true;
              handle.setPointerCapture(event.pointerId);
              row.classList.toggle('is-dragging', true);
            });
            handle.addEventListener('pointermove', (event) => {
              if (!dragging) return;
              const target = document.elementFromPoint(event.clientX, event.clientY)?.closest('.activity-manager-row');
              const other = drafts.find((item) => item.row === target && item.category === key);
              if (other && other !== draft) {
                moveActivity(draft, orders.get(key).indexOf(other.id));
                // Reacquire capture after moving the handle's row in the DOM.
                handle.setPointerCapture(event.pointerId);
              }
              const bounds = dialog.getBoundingClientRect();
              if (event.clientY < bounds.top + 50) dialog.scrollTop -= 16;
              if (event.clientY > bounds.bottom - 50) dialog.scrollTop += 16;
            });
            const stopDrag = () => { dragging = false; row.classList.toggle('is-dragging', false); };
            handle.addEventListener('pointerup', stopDrag);
            handle.addEventListener('pointercancel', stopDrag);
            handle.addEventListener('lostpointercapture', stopDrag);
            controls.push(nameInput, pointsInput);
            const undo = UI.button('Undo', () => {
              if (saving || locked || undo.disabled) return;
              const current = data.activities.find((item) => item._id === activity._id);
              draft.deleted = false;
              nameInput.value = current.title;
              pointsInput.value = String(current.maxScore);
              if (weightInput) weightInput.value = current.wsPercentage === undefined ? '' : String(current.wsPercentage);
              changed();
            });
            undo.className += ' activity-undo';
            undo.setAttribute('aria-label', 'Undo changes to ' + activity.title);
            function changed() {
              const current = data.activities.find((item) => item._id === activity._id);
              row.hidden = !current;
              nameInput.disabled = pointsInput.disabled = saving || locked || draft.deleted || !current;
              if (weightInput) weightInput.disabled = nameInput.disabled;
              handle.disabled = nameInput.disabled;
              deleteColumn.disabled = saving || locked || draft.deleted || !current;
              deleteColumn.textContent = draft.deleted ? 'Pending deletion' : 'Delete';
              undo.disabled = saving || locked || !current ||
                (!draft.deleted && nameInput.value === current.title && pointsInput.value === String(current.maxScore) &&
                  (!weightInput || weightInput.value === (current.wsPercentage === undefined ? '' : String(current.wsPercentage))));
            }
            refreshUndo.push(changed);
            nameInput.addEventListener('input', changed);
            pointsInput.addEventListener('input', changed);
            weightInput?.addEventListener('input', changed);
            undo.title = 'Restore this row to its saved name and maximum points';
            const deleteColumn = UI.button('Delete', () => {
              if (saving || locked || draft.deleted) return;
              draft.deleted = true;
              changed();
            });
            deleteColumn.className += ' activity-delete';
            deleteColumn.disabled = locked;
            deleteColumn.setAttribute('aria-label', 'Delete ' + activity.title);
            changed();
            controls.push(undo, deleteColumn);
            const rowActions = UI.node('div', undefined, 'activity-manager-row-actions');
            rowActions.append(undo, deleteColumn);
            row.append(handle, info, rowActions);
            section.appendChild(row);
          });
          manager.appendChild(section);
        });
        const managerStatus = UI.node('p');
        managerStatus.className = 'activity-manager-status';
        managerStatus.setAttribute('role', 'status');
        const buttons = UI.node('div', undefined, 'activity-editor-actions');
        const dismiss = UI.button('Cancel', () => dialog.close());
        const commit = UI.node('button', 'Save changes', 'filter-btn');
        commit.type = 'submit';
        commit.hidden = true;
        commit.disabled = locked || !drafts.length;
        controls.push(dismiss, commit);
        buttons.append(dismiss, commit);
        manager.append(managerStatus, buttons);
        // Reveal invalid fields before browser validation tries to focus them.
        manager.noValidate = true;
        manager.onsubmit = async (event) => {
          event.preventDefault();
          if (saving || locked || !categorySelect.value) return;
          const invalid = drafts.find((draft) => !draft.deleted && (
            !draft.nameInput.value.trim() ||
            draft.nameInput.checkValidity?.() === false ||
            draft.pointsInput.checkValidity?.() === false ||
            draft.weightInput?.checkValidity?.() === false
          ));
          if (invalid) showCategory(invalid.category);
          const missingWeight = drafts.find((draft) => !draft.deleted && draft.weightInput &&
            (!draft.weightInput.value.trim() || !Number.isFinite(Number(draft.weightInput.value)) ||
              Number(draft.weightInput.value) <= 0 || Number(draft.weightInput.value) > 100));
          if (missingWeight) {
            showCategory('examination');
            managerStatus.textContent = 'Enter a WS Percentage greater than 0 and at most 100 for each examination.';
            missingWeight.weightInput.focus();
            return;
          }
          if (!manager.reportValidity()) return;
          const changes = drafts
            .map((draft) => ({
              id: draft.id,
              deleted: draft.deleted,
              title: draft.nameInput.value.trim(),
              maxScore: Number(draft.pointsInput.value),
              wsPercentage: draft.weightInput ? Number(draft.weightInput.value) : undefined
            }))
            .filter((draft) => {
              const current = data.activities.find((item) => item._id === draft.id);
              return (
                current && (draft.deleted || current.title !== draft.title || current.maxScore !== draft.maxScore || current.wsPercentage !== draft.wsPercentage)
              );
            });
          if (changes.some((item) => !item.deleted && !item.title)) {
            managerStatus.textContent = 'Enter an activity name for every column.';
            return;
          }
          saving = true;
          controls.forEach((control) => {
            control.disabled = true;
          });
          managerStatus.textContent = 'Saving changes...';
          let completed = 0;
          try {
            for (const change of changes) {
              const result = await UI.api(
                '/teacher/subjects/' +
                  encodeURIComponent(subject._id) +
                  '/activities/' +
                  encodeURIComponent(change.id),
                {
                  method: change.deleted ? 'DELETE' : 'PUT',
                  body: JSON.stringify({
                    title: change.title,
                    maxScore: change.maxScore,
                    wsPercentage: change.wsPercentage,
                    version: data.gradeVersion || 0
                  })
                }
              );
              if (request !== version) return;
              data.activities = result.activities;
              data.gradeVersion = result.gradeVersion;
              data.gradeStatus = 'draft';
              if (!change.deleted && change.wsPercentage !== undefined &&
                  data.activities.find((activity) => activity._id === change.id)?.wsPercentage !== change.wsPercentage)
                throw new Error('The server did not save the WS Percentage. Restart the backend with the latest code, then save again.');
              if (change.deleted) {
                for (const draftKey of scoreDrafts.keys()) {
                  if (draftKey.startsWith(subject._id + ':') && draftKey.endsWith(':' + change.id))
                    scoreDrafts.delete(draftKey);
                }
              }
              completed++;
            }
            for (const [category, order] of orders) {
              const current = data.activities.filter((activity) => activity.term === Number(select.value) && activity.category === category).map((activity) => activity._id);
              const desired = order.filter((id) => current.includes(id));
              if (desired.every((id, index) => id === current[index])) continue;
              const result = await UI.api('/teacher/subjects/' + encodeURIComponent(subject._id) + '/activity-order', {
                method: 'PUT', body: JSON.stringify({ term: Number(select.value), category, activityIds: desired, version: data.gradeVersion || 0 })
              });
              if (request !== version) return;
              data.activities = result.activities;
              data.gradeVersion = result.gradeVersion;
              data.gradeStatus = 'draft';
              completed++;
            }
            dialog.close();
            render();
            message(completed ? 'Column changes saved.' : 'No changes to save.');
          } catch (error) {
            if (request === version) {
              render();
              managerStatus.textContent =
                (completed ? completed + ' column(s) saved. ' : '') + error.message;
              managerStatus.scrollIntoView?.({ block: 'nearest' });
            }
          } finally {
            saving = false;
            controls.forEach((control) => {
              control.disabled = false;
            });
            refreshUndo.forEach((refresh) => refresh());
          }
        };
        if (categories.some(([key]) => key === initialCategory)) showCategory(initialCategory);
        if (!dialog.open) dialog.showModal();
      }
      function showEditor() {
        dialog.classList.toggle('managing-columns', false);
        manager.hidden = true;
        editor.hidden = false;
        titleInput.setAttribute('aria-invalid', 'false');
        maxInput.setAttribute('aria-invalid', 'false');
        dialog.setAttribute('aria-labelledby', 'activity-editor-title');
        if (!dialog.open) dialog.showModal();
        titleInput.focus();
      }
      function editActivity(activity) {
        if (saving || gradesLocked()) return;
        editingActivity = activity;
        titleInput.value = activity.title;
        maxInput.value = activity.maxScore;
        editorTitle.textContent = 'Edit column';
        save.textContent = 'Save changes';
        remove.hidden = false;
        titleInput.classList.toggle('state-error', false);
        maxInput.classList.toggle('state-error', false);
        editorStatus.textContent = '';
        showEditor();
      }
      function addActivity(category, label, count) {
        if (saving || gradesLocked()) return;
        editingActivity = null;
        remove.hidden = true;
        save.textContent = 'Add activity';
        editingCategory = category;
        wsLabel.hidden = category !== 'examination';
        wsInput.disabled = category !== 'examination';
        wsInput.required = category === 'examination';
        wsInput.value = '';
        editorTitle.textContent = 'Add ' + label + ' activity';
        titleInput.value = '';
        titleInput.placeholder = label + ' ' + (count + 1);
        maxInput.value = '';
        titleInput.classList.toggle('state-error', false);
        maxInput.classList.toggle('state-error', false);
        editorStatus.textContent = '';
        showEditor();
      }
      editor.addEventListener('submit', (event) => {
        event.preventDefault();
        return persist(false);
      });
      async function persist(deleting) {
        if (saving || (deleting && !editingActivity)) return;
        if (!deleting) {
          const missingName = !titleInput.value.trim();
          const invalidMax =
            !String(maxInput.value).trim() ||
            !Number.isInteger(Number(maxInput.value)) ||
            Number(maxInput.value) < 1 ||
            Number(maxInput.value) > 10000;
          titleInput.classList.toggle('state-error', missingName);
          titleInput.setAttribute('aria-invalid', String(missingName));
          maxInput.classList.toggle('state-error', invalidMax);
          maxInput.setAttribute('aria-invalid', String(invalidMax));
          if (missingName || invalidMax) {
            editorStatus.textContent = missingName
              ? 'Activity name is required. Enter a name and maximum points before saving.'
              : 'Maximum points is required and must be a whole number from 1 to 10000.';
            (missingName ? titleInput : maxInput).focus();
            return;
          }
          if (editingCategory === 'examination' &&
              (!wsInput.value.trim() || !Number.isFinite(Number(wsInput.value)) || Number(wsInput.value) <= 0 || Number(wsInput.value) > 100)) {
            editorStatus.textContent = 'WS Percentage must be greater than 0 and at most 100.';
            wsInput.focus();
            return;
          }
          if (!editor.reportValidity()) return;
        }
        saving = true;
        save.disabled = cancel.disabled = remove.disabled = select.disabled = back.disabled = true;
        titleInput.disabled = maxInput.disabled = true;
        editorStatus.textContent = deleting ? 'Deleting column...' : 'Saving activity...';
        try {
          const result = await UI.api(
            '/teacher/subjects/' +
              encodeURIComponent(subject._id) +
              '/activities' +
              (editingActivity ? '/' + encodeURIComponent(editingActivity._id) : ''),
            {
              method: deleting ? 'DELETE' : editingActivity ? 'PUT' : 'POST',
              body: JSON.stringify({
                term: Number(select.value),
                category: editingCategory,
                title: titleInput.value.trim(),
                maxScore: Number(maxInput.value),
                ...(editingCategory === 'examination' ? { wsPercentage: Number(wsInput.value) } : {}),
                version: data.gradeVersion || 0
              })
            }
          );
          if (request !== version) return;
          data.activities = result.activities;
          data.gradeVersion = result.gradeVersion;
          data.gradeStatus = 'draft';
          if (deleting) {
            for (const key of scoreDrafts.keys()) {
              if (key.startsWith(subject._id + ':') && key.endsWith(':' + editingActivity._id))
                scoreDrafts.delete(key);
            }
          }
          dialog.close();
          manager.replaceChildren();
          render();
          message(
            deleting ? 'Column deleted.' : editingActivity ? 'Column updated.' : 'Activity added.'
          );
        } catch (error) {
          if (request === version) editorStatus.textContent = error.message;
        } finally {
          saving = false;
          save.disabled =
            cancel.disabled =
            remove.disabled =
            select.disabled =
            back.disabled =
              false;
          titleInput.disabled = maxInput.disabled = false;
        }
      }
      const content = UI.node('div');
      detail.appendChild(content);
      const scoreTools = UI.node('div', undefined, 'workflow-toolbar score-tools');
      const scoreStatus = UI.node('p');
      scoreStatus.setAttribute('role', 'status');
      const saveScores = UI.button('Save scores', saveActivityScores);
      saveScores.id = 'save-activity-scores';
      scoreTools.append(scoreStatus, saveScores);
      detail.appendChild(scoreTools);
      let summaryUpdates = [];
      function refreshScoreControls() {
        summaryUpdates.forEach((update) => update());
        const invalid = scoreInputs.some((field) => field.invalid);
        const dirty = scoreInputs.some((field) => scoreDrafts.has(field.key));
        const unsaved = [...scoreDrafts.keys()].some((key) => key.startsWith(subject._id + ':'));
        const complete = data?.roster?.length > 0 && data.roster.every((student) => finalAverage(calculatedTerms(student)) !== null);
        finalizeButton.hidden = false;
        finalizeButton.textContent = data?.gradeStatus === 'finalized' ? 'Grades finalized' : 'Finalize grades';
        finalizeButton.disabled = saving || unsaved || !complete || data?.gradeStatus === 'finalized' || !(data?.canFinalize ?? data?.canRequestEdit);
        finalizeButton.title = unsaved ? 'Save scores in every term first.' : !complete ? 'Complete all three terms for every learner first.' : !(data?.canFinalize ?? data?.canRequestEdit) ? 'A class adviser must be assigned first.' : 'Confirm saved grades for final reports. Editing later returns them to Draft.';
        saveScores.disabled = saving || gradesLocked() || !dirty || invalid;
        scoreStatus.textContent = invalid
          ? 'Fix the highlighted scores before saving.'
          : dirty
            ? 'Unsaved scores. Save scores includes changes on every page of this term.'
            : '';
      }
      function examinationCells(student, group) {
        const cells = [...group.activities.map((activity) => 'WS ' + activity.title), 'PS', 'WS']
          .map((label) => {
            const cell = UI.node('span', '\u2014', 'examination-summary-value');
            cell.setAttribute('aria-label', fullName(student) + ' - ' + label);
            return cell;
          });
        const update = () => {
          const weighted = group.activities.map((activity) => {
            const field = scoreInputs.find((item) => item.student === student && item.activity === activity);
            return field && !field.invalid && field.input.value !== '' &&
              typeof activity.wsPercentage === 'number' && activity.wsPercentage > 0
              ? Number(field.input.value) / activity.maxScore * activity.wsPercentage : null;
          });
          const ps = window.TermGrades.examinationPS(group.activities, weighted);
          [...weighted, ps, ps === null ? null : ps * group.weight / 100].forEach((value, index) => {
            cells[index].textContent = value === null ? '\u2014' : String(Number(value.toFixed(2)));
          });
        };
        summaryUpdates.push(update);
        update();
        return cells;
      }
      function summaryCells(student, group) {
        const cells = ['Total', 'PS', 'WS'].map((label) => {
          const cell = UI.node('span', '\u2014', 'activity-summary-value');
          cell.setAttribute('aria-label', fullName(student) + ' - ' + group.label + ' ' + label);
          return cell;
        });
        const update = () => {
          const fields = scoreInputs.filter((field) =>
            field.student === student && group.activities.includes(field.activity)
          );
          const complete = fields.length > 0 && fields.every((field) =>
            !field.invalid && field.input.value !== ''
          );
          const total = complete ? fields.reduce((sum, field) => sum + Number(field.input.value), 0) : null;
          const ps = total !== null && group.maximum > 0 ? total / group.maximum * 100 : null;
          const ws = ps !== null && group.weight !== null ? ps * group.weight / 100 : null;
          [total, ps, ws].forEach((value, index) => {
            cells[index].textContent = value === null ? '\u2014' : String(Number(value.toFixed(2)));
          });
          cells[2].title = group.weight === null ? 'Category weight has not been configured.' : 'Percentage Score × category weight';
        };
        summaryUpdates.push(update);
        update();
        return cells;
      }
      function calculatedTerms(student) {
        const scores = { ...student.activityScores };
        for (const activity of data.activities || []) {
          const draft = scoreDrafts.get(subject._id + ':' + student.studentId + ':' + activity._id);
          if (draft) scores[activity._id] = draft.raw === '' ? null : Number(draft.raw);
        }
        scoreInputs.filter((field) => field.student === student).forEach((field) => {
          scores[field.activity._id] = field.invalid || field.input.value === '' ? null : Number(field.input.value);
        });
        return Object.fromEntries([1, 2, 3].map((term) => [term,
          window.TermGrades.calculate(data.activities || [], scores, term)
        ]));
      }
      function termGradeCell(grade) {
        const cell = UI.node('span');
        updateTermGrade(cell, grade);
        return cell;
      }
      function updateTermGrade(cell, grade) {
        cell.textContent = grade === null || grade === undefined ? '\u2014' : String(grade);
        cell.className = grade === null || grade === undefined ? '' : grade < 75 ? 'term-grade-failed' : 'term-grade-passed';
        cell.title = grade === null || grade === undefined ? 'Not graded' : grade < 75 ? 'Failed' : 'Passed';
      }
      function termCells(student) {
        const initial = UI.node('span'), grade = UI.node('span'), descriptor = UI.node('span');
        const update = () => {
          const term = calculatedTerms(student)[Number(select.value)];
          initial.textContent = term.initialGrade === null ? '\u2014' : term.initialGrade.toFixed(2);
          updateTermGrade(grade, term.termGrade);
          descriptor.textContent = term.descriptor;
        };
        summaryUpdates.push(update);
        update();
        return [initial, grade, descriptor];
      }
      function scoreCell(student, activity) {
        const cell = UI.node('div', undefined, 'activity-score-cell');
        const input = UI.node('input', undefined, 'activity-score-input');
        const error = UI.node('small', '', 'activity-score-error');
        const key = subject._id + ':' + student.studentId + ':' + activity._id;
        const original = student.activityScores?.[activity._id] ?? null;
        const draft = scoreDrafts.get(key);
        Object.assign(input, {
          type: 'number',
          min: '0',
          max: String(activity.maxScore),
          step: 'any',
          value: draft ? draft.raw : original === null ? '' : String(original),
          placeholder: '\u2014',
          disabled: gradesLocked()
        });
        input.setAttribute(
          'aria-label',
          fullName(student) + ' - ' + activity.title + ' (maximum ' + activity.maxScore + ')'
        );
        error.id = 'score-error-' + student.studentId + '-' + activity._id;
        error.hidden = true;
        input.setAttribute('aria-describedby', error.id);
        const field = { input, key, student, activity, invalid: false };
        scoreInputs.push(field);
        function validate(changed) {
          const raw = input.value,
            number = Number(raw);
          field.invalid =
            Boolean(input.validity?.badInput) ||
            (raw !== '' && (!Number.isFinite(number) || number < 0 || number > activity.maxScore));
          input.classList.toggle('state-error', field.invalid);
          input.setAttribute('aria-invalid', String(field.invalid));
          error.textContent = field.invalid ? 'Enter 0 to ' + activity.maxScore + ' points.' : '';
          error.hidden = !field.invalid;
          if (changed) {
            if (!field.invalid && (raw === '' ? null : number) === original)
              scoreDrafts.delete(key);
            else scoreDrafts.set(key, { raw });
          }
          refreshScoreControls();
        }
        input.addEventListener('input', () => validate(true));
        validate(false);
        cell.append(input, error);
        return cell;
      }
      async function saveActivityScores() {
        if (
          saving ||
          gradesLocked() ||
          scoreInputs.some((field) => field.invalid)
        )
          return;
        const changed = scoreInputs.filter((field) => scoreDrafts.has(field.key));
        if (!changed.length) return;
        const entries = new Map();
        changed.forEach((field) => {
          if (!entries.has(field.student.studentId))
            entries.set(field.student.studentId, {
              studentId: field.student.studentId,
              scores: {}
            });
          entries.get(field.student.studentId).scores[field.activity._id] =
            field.input.value === '' ? null : Number(field.input.value);
        });
        saving = true;
        select.disabled = back.disabled = manage.disabled = true;
        scoreInputs.forEach((field) => {
          field.input.disabled = true;
        });
        refreshScoreControls();
        scoreStatus.textContent = 'Saving scores...';
        try {
          const result = await UI.api(
            '/teacher/subjects/' + encodeURIComponent(subject._id) + '/activity-scores',
            {
              method: 'PUT',
              body: JSON.stringify({
                version: data.gradeVersion || 0,
                term: Number(select.value),
                grades: Array.from(entries.values())
              })
            }
          );
          if (request !== version) return;
          data.gradeVersion = result.gradeVersion;
          data.gradeStatus = 'draft';
          changed.forEach((field) => {
            field.student.activityScores ||= {};
            field.student.activityScores[field.activity._id] = entries.get(
              field.student.studentId
            ).scores[field.activity._id];
            scoreDrafts.delete(field.key);
          });
          render();
          scoreStatus.textContent = 'Scores saved.';
        } catch (error) {
          if (request === version)
            scoreStatus.textContent = 'Could not save scores: ' + error.message;
        } finally {
          saving = false;
          select.disabled = back.disabled = false;
          manage.disabled = gradesLocked();
          scoreInputs.forEach((field) => {
            field.input.disabled = gradesLocked();
          });
          saveScores.disabled =
            gradesLocked() ||
            !scoreInputs.some((field) => scoreDrafts.has(field.key)) ||
            scoreInputs.some((field) => field.invalid);
        }
      }
      function render() {
        requestEdit.hidden = !(data.canRequestEdit || (deadlinePassed() && data.subjectHeadAssigned && !data.isSubjectHead && !data.editPermissionGranted));
        requestEdit.disabled = data.requests?.some((item) => item.status === 'pending') || false;
        deadlineNote.hidden = data.canEditGrades === undefined;
        deadlineNote.textContent = data.gradingDeadline ? 'Grading deadline: ' + new Date(data.gradingDeadline).toLocaleString() + (gradesLocked() ? '. Grades are locked; request approval from your subject head.' : data.isSubjectHead ? '. Subject head: you may edit your assigned grades anytime.' : '. Grade editing is available.') : 'No grading deadline has been set.';

        content.replaceChildren();
        scoreInputs = [];
        summaryUpdates = [];
        const final = select.value === '4';
        scoreTools.hidden = final;
        manage.hidden = final;
        manage.disabled = gradesLocked();
        const groups = categories.map(([key, label]) => {
          const activities = (data.activities || []).filter(
            (activity) => activity.term === Number(select.value) && activity.category === key
          );
          return {
            activities,
            label,
            summary: true,
            examination: key === 'examination',
            maximum: activities.reduce((sum, activity) => sum + activity.maxScore, 0),
            weight: categoryWeights[key] ?? null,
            locked: gradesLocked(),
            add: () => addActivity(key, label, activities.length)
          };
        });
        const missingWeights = groups[2].activities.filter((activity) =>
          typeof activity.wsPercentage !== 'number' || !Number.isFinite(activity.wsPercentage) ||
          activity.wsPercentage <= 0 || activity.wsPercentage > 100
        );
        if (!final && missingWeights.length) {
          const notice = UI.node('div', undefined, 'workflow-status is-error');
          notice.id = 'examination-weight-notice';
          notice.setAttribute('role', 'status');
          notice.appendChild(UI.node('p', 'Examination WS and PS need a WS Percentage for: ' +
            missingWeights.map((activity) => activity.title).join(', ') +
            '. Maximum points and WS Percentage are separate settings.'));
          if (!gradesLocked())
            notice.appendChild(UI.button('Set examination percentages', () => manageColumns('examination')));
          content.appendChild(notice);
        }
        const body = table(
          content,
          subject.name + ' — ' + subject.className + ' · ' + select.selectedOptions[0].textContent,
          final ? finalColumns : termColumns,
          'class-grades-tbody',
          final ? null : groups
        );
        const rows = [...data.roster].sort((a, b) =>
          fullName(a).localeCompare(fullName(b), 'en', { sensitivity: 'base' })
        );
        const pageCount = Math.max(1, Math.ceil(rows.length / rosterPageSize));
        rosterPage = Math.min(rosterPage, pageCount);
        const renderedRows = [];
        rows.forEach((student) => {
          let studentRow;
          const terms = data.activities?.length ? calculatedTerms(student) : student.terms || {};
          if (final) {
            const average = finalAverage(terms);
            studentRow = UI.row(body, [
              fullName(student),
              termGradeCell(terms[1]?.termGrade),
              termGradeCell(terms[2]?.termGrade),
              termGradeCell(terms[3]?.termGrade),
              average === null ? null : average.toFixed(2),
              average === null ? null : window.TermGrades.descriptor(average),
              average === null ? 'Incomplete' : average >= 75 ? 'Passed' : 'Failed'
            ]);
          } else {
            const activityValues = groups.flatMap((group) => {
              const values = group.activities.length
                ? group.activities.map((activity) => scoreCell(student, activity))
                : [null];
              if (group.examination) values.push(...examinationCells(student, group));
              else values.push(...summaryCells(student, group));
              return values;
            });
            studentRow = UI.row(body, [
              student.lrn || '—',
              fullName(student),
              ...activityValues,
              ...termCells(student)
            ]);
          }
          renderedRows.push(studentRow);
        });
        const pagination = UI.node('nav', undefined, 'workflow-toolbar class-pagination');
        pagination.setAttribute('aria-label', 'Class table pages');
        const pageLabel = UI.node('span');
        pageLabel.id = 'class-roster-page';
        pageLabel.setAttribute('aria-live', 'polite');
        const previous = UI.button('Previous', () => {
          if (!saving && rosterPage > 1) { rosterPage--; updatePage(); }
        });
        previous.id = 'class-roster-prev';
        const next = UI.button('Next', () => {
          if (!saving && rosterPage < pageCount) { rosterPage++; updatePage(); }
        });
        next.id = 'class-roster-next';
        function updatePage() {
          renderedRows.forEach((row, index) => {
            row.hidden = index < (rosterPage - 1) * rosterPageSize || index >= rosterPage * rosterPageSize;
          });
          previous.disabled = rosterPage <= 1;
          next.disabled = rosterPage >= pageCount;
          const first = rows.length ? (rosterPage - 1) * rosterPageSize + 1 : 0;
          pageLabel.textContent = 'Page ' + rosterPage + ' of ' + pageCount +
            ' ? Showing ' + first + '?' + Math.min(rosterPage * rosterPageSize, rows.length) + ' of ' + rows.length + ' students';
        }
        pagination.append(previous, pageLabel, next);
        content.appendChild(pagination);
        updatePage();
        refreshScoreControls();
        if (!rows.length)
          UI.empty(
            body,
            'No students enrolled in this subject. Registered learners appear here once enrolled.',
            final
              ? 7
              : 5 + groups.reduce((count, group) => count + Math.max(1, group.activities.length) + (group.examination ? group.activities.length + 2 : 3), 0)
          );
        if (final)
          content.appendChild(
            UI.node(
              'p',
              'Final Grade is the equal average of all three term grades, displayed to two decimal places. All three terms must be complete.',
              'table-footnote'
            )
          );
        if (!final && rows.length)
          content.appendChild(
            UI.node('p', 'Initial Grade is the sum of the three category weighted scores. Examination PS is the sum of exam contributions divided by the total exam weight, multiplied by 100; Examination WS is 20% of PS. Complete all activities and examination percentages to calculate the Term Grade.', 'table-footnote')
          );
      }
      select.disabled = true;
      select.addEventListener('change', () => {
        rosterPage = 1;
        dialog.close();
        render();
      });
      message('Loading learners…');
      try {
        const result = await UI.api(
          '/teacher/subjects/' + encodeURIComponent(subject._id) + '/roster'
        );
        if (request !== version) return;
        data = result;
        render();
        scheduleDeadline();
        select.disabled = false;
        message();
      } catch (error) {
        if (request === version) message('Could not load learners: ' + error.message, true);
      }
    }
    return {
      show,
      setSubjects(value) {
        subjects = value;
        selected = null;
        data = null;
        version++;
      }
    };
  }
  return { create };
})();
